class Country():

    def __init__(self, name, code):
        self.name = name
        self.code = code